程式需求：
1.python 2.7以上  (python 3 未測試）
2.python套件 selenium
3.chrome驅動 chromedriver（與程式放在同目錄下）

抓取對應的作業系統之chromedriver
（http://chromedriver.storage.googleapis.com/index.html?path=2.20/）

說明：
python直接執行即可